add crypto secure algos
complete rust port
other langs - .js?
