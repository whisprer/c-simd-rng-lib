16bit
32bit
64bit
128bit
256bit
512bit
1024bit

working
faster
all above
all above faster

benchmarker
command line select of:
- bits
- forced hardware mode/bypass hardware mode

