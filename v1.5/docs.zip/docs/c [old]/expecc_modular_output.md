=== WYRAND (NON-OPTIMIZED) BENCH ===
[ prints usage, times, speedups, etc. ]

=== WYRAND (OPTIMIZED) BENCH ===
[ prints usage, times, speedups, etc. ]

=== XOROSHIRO128++ (NON-OPTIMIZED) BENCH ===
[ prints usage, times, speedups, etc. ]

=== XOROSHIRO128++ (OPTIMIZED) BENCH ===
[ prints usage, times, speedups, etc. ]
